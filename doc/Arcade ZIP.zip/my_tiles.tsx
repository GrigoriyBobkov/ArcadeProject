<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="my_tiles" tilewidth="16" tileheight="16" spacing="1" tilecount="400" columns="20">
 <image source="../../Downloads/kenney_1-bit-platformer-pack/Tilemap/monochrome_tilemap.png" width="339" height="339"/>
</tileset>
